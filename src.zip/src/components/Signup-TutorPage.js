import React from 'react';

function SignupTutor() {
  return <div><h1>Sign up as a Tutor</h1></div>;
}

export default SignupTutor;
