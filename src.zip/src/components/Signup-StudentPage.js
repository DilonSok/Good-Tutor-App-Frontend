import React from 'react';

function SignupStudent() {
  return <div><h1>Sign up as a Student</h1></div>;
}

export default SignupStudent;