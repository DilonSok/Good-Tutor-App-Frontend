import '../css/general.css';

function general(){
    return(
        <div className='space'></div>
    );
}

export default general;